<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class Oauth2SettingController extends Controller
{
    //
    public function index(Request $request){
        if (session()->has('token')){
            redirect()->route('welcome');
        }
        $oauth2_setting = DB::table('oauth2_settings')
            ->orderBy('id', 'desc')
            ->take(1)
            ->get();

        $id = $clientId = $redirectUri = $oauth2Url = $clientSecret = '';
        if($oauth2_setting != null && count($oauth2_setting) > 0){
            $clientId = $oauth2_setting[0]->client_id;
            $redirectUri = $oauth2_setting[0]->redirect_uri;
            $oauth2Url = $oauth2_setting[0]->oauth2_url;
            $clientSecret = $oauth2_setting[0]->client_secret;
            $id = $oauth2_setting[0]->id;
        }

        return view('oauth2_setting')->with([
            'clientId' => $clientId,
            'redirectUri' => $redirectUri,
            'oauth2Url' => $oauth2Url,
            'clientSecret' => $clientSecret,
            'id' => $id
        ]);
    }

    public function saveOauth2(Request $request){
        if(isset($request->id) && $request->id > 0){
            DB::table('oauth2_settings')
                ->where('id', $request->id)
                ->update([
                    'client_id' => $request->client_id,
                    'redirect_uri' => $request->redirect_uri,
                    'oauth2_url' => $request->oauth2_url,
                    'client_secret' => $request->client_secret,
                ]);
        }else{
            DB::table('oauth2_settings')
                ->insert([
                    'client_id' => $request->client_id,
                    'redirect_uri' => $request->redirect_uri,
                    'oauth2_url' => $request->oauth2_url,
                    'client_secret' => $request->client_secret,
                ]);
        }
        return redirect()->route('home');
    }
}
