<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Oauth2Setting;
use Faker\Generator as Faker;

$factory->define(Oauth2Setting::class, function (Faker $faker) {
    return [
        //
    ];
});
