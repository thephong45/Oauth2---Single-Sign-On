<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 style="padding-left: 250px;font-weight: bold">BẢNG DANH SÁCH CÁC USER</h2>
                <a href="<?php echo e(route('addUser')); ?>"><button class="btn btn-success" style="margin-bottom: 15px;">Add User</button></a>
                <table class="table table-bordered">
                    <tr>
                        <th>STT</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th width="80px"></th>
                        <th width="80px"></th>
                    </tr>
                    <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="r_<?php echo e($item->id); ?>">
                            <td><?php echo e($index++); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format("d/m/Y")); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($item->updated_at)->format("d/m/Y")); ?></td>

                            <td><a href="<?php echo e(route('editUser')); ?>?id=<?php echo e($item->id); ?>"><button class="btn btn-warning">Edit</button></a></td>
                            <td><button onclick="deleteUser(<?php echo e($item->id); ?>)" class="btn btn-danger">Delete</button></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($userList->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        function deleteUser(id) {
            $.post('<?php echo e(route('deleteUser')); ?>', {
                _token: '<?php echo e(csrf_token()); ?>',
                id:id
            }, function(data, status) {
                // location.reload();
                $('#r_'+id).remove();
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\student_management\resources\views/student/user/index.blade.php ENDPATH**/ ?>