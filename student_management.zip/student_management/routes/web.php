<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Auth::routes();

Route::get('/settings', 'SettingsController@index')->name('settings');
Route::get('/home', 'HomeController@index')->name('home');

Route::group(['prefix' => '/student/user'], function () {
    Route::get('/edit', 'StudentUserController@editUser')->name('editUser');

    Route::get('add', 'StudentUserController@addUser')->name('addUser');

    Route::post('/post', 'StudentUserController@postUser')->name('postUser');

    Route::get('/list', 'StudentUserController@showAll')->name('showAll');

    Route::post('/delete', 'StudentUserController@deleteUser')->name('deleteUser');
});




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
