jQuery(document).ready(function($) {
  $(".slider").slideshow({
    width      : 900,
    height     : 325,
    transition : ['barLeft', 'barRight']
  });
 });
